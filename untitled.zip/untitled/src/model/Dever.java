package model;

public interface Dever {
}
