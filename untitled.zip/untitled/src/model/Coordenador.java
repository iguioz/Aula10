package model;

public class Coordenador extends Pessoa implements FolhaPagamento{
}
