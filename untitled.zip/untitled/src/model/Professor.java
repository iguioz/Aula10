package model;

public class Professor extends Pessoa implements FolhaPagamento{

    private int cargaHoraria;
    private double salario;

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }



    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }



    public Professor(String nome, int idade) {
        super(nome, idade);
    }

    public Professor() {

    }
}
