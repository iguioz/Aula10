package model;

public interface FolhaPagamento {
}
