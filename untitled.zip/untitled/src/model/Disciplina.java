package model;

public class Disciplina {
}
