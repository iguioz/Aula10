import model.*;
import service.PessoaService;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);
        Scanner scinicio = new Scanner(System.in);
        Pessoa p = new Professor();
        Pessoa a = new Aluno();
        Pessoa c = new Coordenador();
        PessoaService ps = new PessoaService();

        System.out.println("Pressione de acordo com o que deseja fazer!");
        System.out.println("1. Cadastrar");
        System.out.println("2. Deletar");
        System.out.println("3. Atualizar");
        System.out.println("4. Listar os cadastros");
        System.out.println("5. Sair");
        int inicio = scinicio.nextInt();
        switch (inicio) {
            case 1:
                System.out.println("Digite o nome:");
                p.setNome(sc2.next());
                System.out.println("Digite a idade :");
                p.setIdade(sc.nextInt());

                ps.cadastrarPessoa(p);
                break;
            case 2:
                System.out.print("Digite o nome da pessoa que deseja deletar: ");
                String nomeDeletar = sc2.next();
                ps.deletar(nomeDeletar);
                break;
            case 3:
                System.out.print("Digite o nome da pessoa que deseja atualizar: ");
                String nome = sc.next();
                System.out.print("Digite o novo nome da pessoa: ");
                String novoNome = sc.next();
                ps.atualizar(nome, novoNome);
                break;
            case 4:
                System.out.println(ps.listar());
                break;
            case 5:
                break;
        }
    }
}